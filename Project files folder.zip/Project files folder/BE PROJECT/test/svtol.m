function tol = svtol(C)

  if (nargin ~= 1) 
    help svtol
  else

      if C==Inf 
      tol = 1e-5;
    else
      tol = C*1e-6;
    end
    
  end
