% 
%DCT-ANN BASED FACE RECOGNITION
% 
% In order to obtain the complete source code for High Speed Face
% Recognition Based on Discrete Cosine Transforms and Neural Networks
% please visit my website
% 
% http://www.advancedsourcecode.com/dctannface.asp
% 
% A small donation (just 30 Euros, less than 42 U.S. Dollars) is required.
% 
% Date           Release        Major features
%
% 16-05-2006         1.0        - Face recognition based on DCT (Discrete 
%                                 Cosine Transforms) and Neural Networks
%                               - Easy and intuitive GUI
%
% For more informations please email me ( luigi.rosa@tiscali.it )
%
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila --- ITALY 
% email  luigi.rosa@tiscali.it
% mobile +39 320 7214179
% website http://www.advancedsourcecode.com
%
%
%