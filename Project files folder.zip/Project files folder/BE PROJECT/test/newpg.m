%%%% facial Expression using DCT and SVM
close all
clear all;
clc;
cd test
I=uigetfile('.bmp','select any quirey image');
I=imread(I);
cd ..
I=imresize(I,[128 128]);
figure,imshow(I);title('Original quirey image');
I=im2bw(I);
dc=dct2(I);
tes=dc(:,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% training %%%%%%%%%%%%%%%%%%%%%%%%%%
FileNames = dir('train');
FileNames = char(FileNames.name);
for i=1:length(FileNames)-3
cd train
k=imread(strcat(num2str(i),'.bmp'));
cd ..
k=imresize(k,[128 128]);
figure,imshow(k);title('training image');
k=im2bw(k);
dck=dct2(k);
tra=dck(:,1);
[nsv alpha bias] = svc(tes(1:60),tra(1:60));
n(i)=nsv;
mn(i)=max(alpha)*10^-10;
dit(i)=sum(min(dist(tes,tra')));
end
idx=find(min(n)==n);
%%%%% model discussion %%%%%%
if idx==1 || idx==7
    msgbox('The given expression is ANGER');
end
if idx==2 || idx==8
    msgbox('The given expression is FEAR'); 
 end
if idx==3 || idx==9
    msgbox('The given expression is SURPRISE');
end
if idx==4 || idx== 10
   msgbox('The given expression is DISGUST');
end
if idx==6 || idx==5
    msgbox('The given expression is JOY');
end

