function varargout = run(varargin)
% RUN M-file for run.fig
%      RUN, by itself, creates a new RUN or raises the existing
%      singleton*.
%
%      H = RUN returns the handle to a new RUN or the handle to
%      the existing singleton*.
%
%      RUN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RUN.M with the given input arguments.
%
%      RUN('Property','Value',...) creates a new RUN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before run_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to run_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help run

% Last Modified by GUIDE v2.5 16-Feb-2010 02:19:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @run_OpeningFcn, ...
                   'gui_OutputFcn',  @run_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

warning off;
% --- Executes just before run is made visible.
function run_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to run (see VARARGIN)

% Choose default command line output for run
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes run wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = run_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cd test
I=uigetfile('.bmp','select any quirey image');
I=imread(I);
cd ..
I=imresize(I,[128 128]);
axes(handles.axes1)
imshow(I)
I=im2bw(I);
dc=dct2(I);
tes=dc(:,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% training %%%%%%%%%%%%%%%%%%%%%%%%%%
FileNames = dir('train');
FileNames = char(FileNames.name);
for i=1:length(FileNames)-3
cd train
k=imread(strcat(num2str(i),'.bmp'));
cd ..
k=imresize(k,[128 128]);
k=im2bw(k);
dck=dct2(k);
tra=dck(:,1);
[nsv alpha bias] = svc(tes(1:60),tra(1:60));
n(i)=nsv;
mn(i)=max(alpha)*10^-10;
dit(i)=sum(min(dist(tes,tra')));
end
idx=find(min(n)==n);
%%%%% model discussion %%%%%%
if idx==1 || idx==7
    msgbox('The given expression is ANGER');
end
if idx==2 || idx==8
    msgbox('The given expression is FEAR'); 
 end
if idx==3 || idx==9
    msgbox('The given expression is SURPRISE');
end
if idx==4 || idx== 10
   msgbox('The given expression is DISGUST');
end
if idx==6 || idx==5
    msgbox('The given expression is JOY');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s=sort(dit);
for k=1:5
    indx(k)=find(s(k)==dit);
end
cd train
j=imread(strcat(num2str(indx(2)),'.bmp'));
axes(handles.axes2)
imshow(imresize(j,[128 128]));
j=imread(strcat(num2str(indx(3)),'.bmp'));
axes(handles.axes3)
imshow(imresize(j,[128 128]));
j=imread(strcat(num2str(indx(4)),'.bmp'));
axes(handles.axes4)
imshow(imresize(j,[128 128]));
j=imread(strcat(num2str(indx(5)),'.bmp'));
axes(handles.axes5)
imshow(imresize(j,[128 128]));
cd ..

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all


