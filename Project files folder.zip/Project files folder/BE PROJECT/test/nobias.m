function nb = nobias(ker)

  if (nargin ~= 1) 
     help nobias
  else
     
    switch lower(ker)
      case {'linear','sigmoid'}
        nb = 1;
      otherwise
        nb = 0;
    end

  end
