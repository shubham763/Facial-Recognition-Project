% High Speed Face Recognition Based on Discrete Cosine Transforms 
% and Neural Networks
%
% High information redundancy and correlation in face images result in
% ineciencies when such images are used directly for recognition. In
% this paper, discrete cosine transforms are used to reduce image
% information redundancy because only a subset of the transform
% coecients are necessary to preserve the most important facial
% features such as hair outline, eyes and mouth. We demonstrate
% experimentally that when DCT coecients are fed into a backpropagation
% neural network for classi cation, a high recognition rate can be
% achieved by using a very small proportion of transform coecients.
% This makes DCT-based face recognition much faster than other
% approaches. Key words: Face recognition, neural networks, feature
% extraction, discrete cosine transform.
%
% Face images must be collected into sets: every set (called "class") should
% include a number of images for each person, with some variations in 
% expression and in the lighting. When a new input image is read and added
% to the training database, the number of class is required. Otherwise, a new 
% input image can be processed and confronted with all classes present in database.
%
%--------------------------------------------------------------------------
% ----------------------------- INSTRUCTIONS ------------------------------
%--------------------------------------------------------------------------
%
% Copy all files in Matlab current directory and type "dctann" on
% Matlab command window.
% 
% First, select an input image clicking on "Select image".
% Then you can
%   - add this image to database (click on "Add selected image to database"
%   - perform face recognition (click on "Face Recognition" button)
%     Note: If you want to perform face recognition database has to include 
%     at least one image.
%  If you choose to add image to database, a positive integer (face ID) is
%  required. This posivive integer is a progressive number which identifies
%  a person (each person corresponds to a class).
% For example:
%  - run the GUI (type "dctann" on Matlab command window)
%  - delete database (click on "Delete Database")
%  - add "mike1.jpg" to database ---> the ID has to be 1 since Mike is the first
%    person you are adding to database
%  - add "mike2.jpg" to database ---> the ID has to be 1 since you have already
%    added a Mike's image to database
%  - add "paul1.jpg" to database ---> the ID has to be 2 since Paul is the second person
%    you are adding to database
%  - add "cindy1.jpg" to database ---> the ID has to be 3 since Cindy is
%    the third person you are adding to database
%  - add "paul2.jpg" to database ---> the ID has to be 2 once again since
%    you have already added Paul to database
%   
% ... and so on! Very simple, isnt't? :)
% 
% The recognition gives as results the ID of nearest person present in
% database. For example if you select image "paul3.jpg" the ID given SHOULD
% be 2: "it should be" because errors are possible.
%
%
% The images included are taken from AT&T Laboratories Cambridge's
% Face DataBase. See the cited references for more informations.
% 
% 
% FUNCTIONS
%
% Select image:                                  read the input image
%
% Add selected image to database:                the input image is added to database and will be used for training
%
% Database Info:                                 show informations about the images present in database.
%
% Face Recognition:                              face matching. The selected input image is processed
%
% Delete Database:                               remove database from the current directory
%
% Info:                                          show informations about this software
%
%
% Source code for Face Recognition System:       how to obtain the complete source code
%
% Exit:                                          quit program
%
%
%  References:
%  Zhengjun Pan and Hamid Bolouri, "High Speed Face Recognition Based on
%  Discrete Cosine Transforms and Neural Networks", 1999
%
%  The corresponding article is available at
%  http://citeseer.ist.psu.edu/pan99high.html
%  
%
%
%  AT&T Laboratories Cambridge. The ORL face database, Olivetti Research Laboratory available at
%  http://www.uk.research.att.com/pub/data/att_faces.zip
%  or http://www.uk.research.att.com/pub/data/att_faces.tar.Z
%
%
%
%
%*****************************************************************
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila --- ITALY 
% email  luigi.rosa@tiscali.it
% mobile +39 3207214179
% website http://www.advancedsourcecode.com
%*****************************************************************
%
%